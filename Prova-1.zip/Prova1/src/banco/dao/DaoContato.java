package banco.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import banco.entidades.Contato;
import banco.mysql.MySql;

public class DaoContato {
	
	public ArrayList<Contato> consultaTodos() {
		
		ArrayList<Contato> c = null;
		
		MySql banco = new MySql();
		
		if(banco.carregaDriver() && banco.conectarBanco() && banco.preparaComando()) {
			
			c = new ArrayList<Contato>();
			String sql = "SELECT * FROM contatos";
			ResultSet r = banco.consultaBanco(sql);
			try {
				while(r.next()) {
					Contato contato = new Contato();
					contato.setId(r.getLong("id"));
					contato.setNome(r.getString("nome"));
					contato.setTelefone(r.getString("telefone"));
					contato.setEmail(r.getString("email"));
					contato.setFoto(r.getBlob("foto"));
					c.add(contato);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			banco.fechaBanco();
		}
		
		return c;
	}
	
	public boolean insereContato(String nome, String telefone, String email) {
		
		MySql banco = new MySql();
		int r=0;
		
		if(banco.carregaDriver() && banco.conectarBanco() && banco.preparaComando()) {
			
			String sql = "INSERT INTO contatos (nome, telefone, email) VALUES ('" + nome + "','" + telefone + "','" + email + "')";
			r = banco.inserirBanco(sql);
			
		}
		if (r >0) {
			return true;
		} else {
			return false;
		}
	}
	

}
